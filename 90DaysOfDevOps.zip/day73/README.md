Day 73 - Grafana 🔥
Hope you are now clear with the basics of grafana, like why we use, where we use, what can we do with this and so on.

Now, let's do some practical stuff.

---

Task:

> Setup grafana in your local environment on AWS EC2.

---

Ref: https://www.linkedin.com/posts/chetanrakhra_devops-project-share-activity-7042518379030556672-ZZA-?utm_source=share&utm_medium=member_desktop

[← Previous Day](../day72/README.md) | [Next Day →](../day74/README.md)
