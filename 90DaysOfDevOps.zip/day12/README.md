## Finally!! 🎉

You have completed the Linux & Git-GitHub handson and I hope you have learned something interesting from it.🙌

Now why not make an interesting 😉 assignment, which not only will help you for the future but also for the DevOps Community!

Let’s make a well articulated and documented **"cheat-sheet"** with all the commands you learned so far in Linux, Git-GitHub and brief info about its usage.

Let’s show us your knowledge mixed with your creativity😎

_I have added a [cheatsheet](https://www.sqltutorial.org/wp-content/uploads/2016/04/SQL-Cheat-Sheet-2.png) for your reference, Make sure every cheatsheet must be UNIQUE_

Post it on Linkedin and Spread the knowledge.😃

**Happy Learning :)**

[← Previous Day](../day11/README.md) | [Next Day →](../day13/README.md)
